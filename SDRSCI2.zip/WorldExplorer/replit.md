# Overview

NRAO Spectrum Sentinels is a citizen science web application for radio astronomy that enables real-time detection and cataloging of radio frequency interference (RFI). The platform allows users to upload radio recordings, automatically processes them to detect interference patterns, and provides an interactive global heatmap to visualize RFI distribution worldwide. The system integrates with SDR Sharp for automated recording capture and reports findings to the SciStarter citizen science platform.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

**Web Framework**: Flask-based web application using SQLAlchemy ORM with declarative base model architecture. The system follows a modular service-oriented design with clear separation between web routes, data models, and processing services. SocketIO provides real-time WebSocket communication for live updates and notifications.

**Database Design**: SQLAlchemy-based data layer supporting both SQLite (development) and PostgreSQL (production) through configurable DATABASE_URL. Core entities include Recording (audio file metadata), UserSession (anonymous user tracking), RFIDetection (interference analysis results), and ProcessingQueue (background task management). Session-based authentication tracks users without requiring registration.

**Signal Processing Engine**: Custom RFI detection system utilizing NumPy and SciPy for digital signal processing. Implements multi-threaded background processing to analyze audio recordings without blocking the web interface. Supports multiple audio formats and automatically extracts frequency domain characteristics for interference detection.

**Real-time Monitoring System**: Watchdog-based file system monitoring for automatic detection of new SDR recordings. When new audio files are created (typically from SDR Sharp), they are automatically queued for processing without manual intervention. Provides live updates to connected clients via WebSocket.

**File Management**: Configurable upload system with intelligent file compression using gzip. Supports large files up to 500MB with automatic directory creation for uploads and audio recordings. Files are processed asynchronously and stored with comprehensive metadata including sample rates, frequency ranges, and processing status.

**Authentication & Session Management**: Session-based user tracking without traditional authentication, designed for anonymous citizen science participation. Includes mandatory age verification (18+) and consent management for research compliance. Tracks user location and activity for scientific data correlation.

# External Dependencies

**SciStarter API Integration**: RESTful API integration for logging citizen science contributions with the National Radio Astronomy Observatory. Automatically tracks user activities, file uploads, and RFI detection results. Requires API key configuration and handles project-specific reporting.

**SDR Sharp Integration**: Automated SDR Sharp configuration and launcher system that optimizes software-defined radio settings for RFI detection. Pre-configures audio recording parameters and provides seamless integration with the web application for hands-free operation.

**Bootstrap & Frontend Libraries**: Responsive web interface built with Bootstrap 5 using Replit's dark theme, Feather Icons for iconography, and Chart.js for interactive data visualization. Includes Leaflet.js for interactive mapping and real-time heatmap generation of global RFI patterns.

**Waitress WSGI Server**: Production-ready WSGI server configuration with multi-threading support for handling concurrent requests and background processing tasks. Configured with connection pooling and proper proxy handling for deployment environments.

**File System Monitoring**: Watchdog library integration for automatic detection of new audio files in configured directories. Enables hands-free operation where SDR recordings are automatically processed as they are created by external software.

**Scientific Computing Stack**: NumPy and SciPy for advanced signal processing algorithms including FFT analysis, spectral density calculations, and statistical interference detection. Provides the mathematical foundation for identifying RFI patterns in radio astronomy data.